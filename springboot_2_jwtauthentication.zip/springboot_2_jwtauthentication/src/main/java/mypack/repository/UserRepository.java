package mypack.repository;  
import org.springframework.data.repository.CrudRepository;
import mypack.model.UserRecord;  
public interface UserRepository extends CrudRepository<UserRecord, Integer> 
{  
}  
