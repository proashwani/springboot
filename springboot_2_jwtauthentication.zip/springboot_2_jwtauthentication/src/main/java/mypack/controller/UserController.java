package mypack.controller;  
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import mypack.model.UserRecord;
import mypack.service.UserService;  
@RestController  
public class UserController 
{  
    @Autowired  
    private UserService userService;   
    @RequestMapping("/")  
    public List<UserRecord> getAllUser()
    {  
    	System.out.println("updated getusers");
        return userService.getAllUsers();  
//    	List<UserRecord> user= new ArrayList<UserRecord>();
//    	UserRecord u1=new UserRecord();
//    	u1.setId(1);
//    	u1.setName("vin");
//    	u1.setEmail("amail");
//    	UserRecord u2=new UserRecord();
//    	u2.setId(2);
//    	u2.setName("kum");
//    	u2.setEmail("bmail");
//    	user.add(u1);
//    	user.add(u2);
    //	return user;
    }     
    @RequestMapping(value="/add-user", method=RequestMethod.POST)  
    public UserRecord addUser(@RequestBody UserRecord userRecord)
    {  
    	System.out.println("---before added---");
        userService.addUser(userRecord);  
        System.out.println("---after added---");
        userRecord.setName("Mr. "+userRecord.getName());
        return userRecord;
        
    }  
    
}  
