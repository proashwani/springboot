package mypack.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mypack.model.UserRecord;
import mypack.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
 
	public List<UserRecord> getAllUsers() {
		List<UserRecord> userRecords = new ArrayList<>();
		userRecords = (List<UserRecord>) userRepository.findAll();
		// .forEach(userRecords::add);
//List<City> cities = (List<City>) repository.findAll();
		System.out.println("************************************");
		System.out.println(userRepository.findAll());
		System.out.println("************************************");
		System.out.println(userRecords);
		System.out.println("************************************");
		return userRecords;
	}

	public void addUser(UserRecord userRecord) {
		userRepository.save(userRecord);
	}
}