package mypack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import mypack.model.UserRecord;
import mypack.service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userService;

	@RequestMapping("/")
	public List<UserRecord> getAllUser() {
		System.out.println("updated getusers");
		return userService.getAllUsers();
	}

	@RequestMapping(value = "/add-user", method = RequestMethod.POST)
	public UserRecord addUser(@RequestBody UserRecord userRecord) {
		System.out.println("---before added---");
		userService.addUser(userRecord);
		int a=10;
		for(int i=0;i<10;i++) {
			a=a+i;
		}
		System.out.println(a);
		System.out.println("---after added---");
		userRecord.setName("Mr. " + userRecord.getName());
		return userRecord;
	}

}
