drop table userrecord if exists
create table userrecord (id integer not null, email varchar(255), name varchar(255), primary key (id))
insert into userrecord values (1,'test1@test.com', 'Blank')
insert into userrecord values (2,'test2@test.com', 'Test')
insert into userrecord values (3,'test3@test.com', 'Default')
insert into userrecord values (4,'test4@test.com', 'none')
