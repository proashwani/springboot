package mypack.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import mypack.model.UserRecord;
import mypack.service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userService;

	@RequestMapping("/")
	public List<UserRecord> getAllUser() {
		System.out.println("updated getusers");
		return userService.getAllUsers();
	}
	
	@RequestMapping(value = "/update-user", method = RequestMethod.POST)
	public UserRecord addUser(@RequestBody UserRecord userRecord) {
		System.out.println("---before added---");
		userService.addUser(userRecord);
		System.out.println("---after added---");
		userRecord.setName("Mr. " + userRecord.getName());
		return userRecord;
	}
	
	
	@RequestMapping(value = "/update-user-with-extra-info", method = RequestMethod.POST)
	public ResponseEntity<UserRecord> addUserWithStatus(@RequestBody UserRecord userRecord) {
		System.out.println("---before added---");
		userService.addUser(userRecord);
		System.out.println("---after added---");
		userRecord.setName("Mr. " + userRecord.getName());
		//getting extra information in response header - location 
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().buildAndExpand().toUri();
		ResponseEntity<UserRecord> resp = ResponseEntity.created(location).body(userRecord);
		return resp;
	}

	@RequestMapping("/getUser/{id}")
	public UserRecord getUser(@PathVariable Integer id) {
		UserRecord user = userService.getAllUsers().stream().filter(usr -> usr.getId() == id).findFirst().get();
		return user;
	}
	
	@PostMapping(value = "/update-user-hateoas")
	public EntityModel<UserRecord> addUserAndgetDetails(@RequestBody UserRecord userRecord) {
		userService.addUser(userRecord);
		userRecord.setName("Mr. " + userRecord.getName());

		Link linkToGetUsers = linkTo(methodOn(this.getClass()).getUser(userRecord.getId())).withRel("getUser");
		Link linkToAllUser = linkTo(methodOn(this.getClass()).getAllUser()).withRel("getAllUsers");
		
		EntityModel<UserRecord> resource = new EntityModel<UserRecord>(userRecord,linkToGetUsers,linkToAllUser);
		return resource;
	}
}
